package sort;

import java.util.Arrays;

public class Test {
    public static void main(String[] args) {
        var numbers = new int[] { 3, 8, 4, 9, 1, 2 };
        var sort = new Sort();

        System.out.println("Original array  : " + Arrays.toString(numbers));

        sort.bubleDesc(numbers);
        System.out.println("Buble sort : " + Arrays.toString(numbers));

        // sort.selection3(numbers);
        // System.out.println("Selection sort : " + Arrays.toString(numbers));

    }

}
